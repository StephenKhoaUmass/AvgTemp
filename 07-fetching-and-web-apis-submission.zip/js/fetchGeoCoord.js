import { fetchJSON } from "../include/fetchJSON.js";
export function getUrl(url, query) {
    const searchURL = new URL(url);
    searchURL.searchParams.append("q", query);
    return searchURL.toString();
}
export function fetchGeoCoord(query) {
    const searchURL = getUrl("https://geocode.maps.co/search", query);
    return fetchJSON(searchURL)
        .then((json) => Array.isArray(json) && json.length > 0
        ? Promise.resolve(json[0])
        : Promise.reject(new Error("No results found for query.")))
        .then(arrObj => {
        const placeGeoCoord = { lat: Number.parseFloat(arrObj.lat), lon: Number.parseFloat(arrObj.lon) };
        return placeGeoCoord;
    });
}
//# sourceMappingURL=fetchGeoCoord.js.map