import { fetchJSON } from "../include/fetchJSON.js";
export function fetchCurrentTemperature(coords) {
    const urlLink = `https://api.open-meteo.com/v1/forecast?latitude=${coords.lat}&longitude=${coords.lon}&hourly=temperature_2m&temperature_unit=fahrenheit`;
    return fetchJSON(urlLink).then((info) => {
        const hourlyData = info.hourly;
        if (hourlyData === undefined || hourlyData.time.length === 0) {
            return Promise.resolve({
                time: [],
                temperature_2m: [],
            });
        }
        return Promise.resolve({
            time: hourlyData.time,
            temperature_2m: hourlyData.temperature_2m,
        });
    });
}
//# sourceMappingURL=fetchCurrentTemperature.js.map